# Group.ONE Gravity Design system

> A Design system is a set of interconnected patterns and shared practices coherently organized. Design systems aid in digital product design and development of products such as applications or websites. They may contain, but are not limited to, pattern libraries, design languages, style guides, coded components, brand languages, and documentation.

Source: https://en.wikipedia.org/wiki/Design_system

The Gravity design system is built to share common design component between different group.ONE applications to have a consistent set of styling. It comes out of the box with branded styling for each major brand in the group.

## Installation

The design system is at its core an NPM package that can be installed either using NPM or YARN.

Make sure the `@group.one` scope is configured. For instruction, and a CI/CD example, see https://gitlab.one.com/nodejs/npm-registry-group.one.

### npm

1. `npm install @group.one/gravity`
2. In your main javascript include:

   ```js
   // ES5
   require("@group.one/gravity");

   // ES6
   import "@group.one/gravity";
   ```

3. In your main stylesheet include one of the brands:
   ```css
   @import "@group.one/gravity/dist/css/brands/one.css";
   ```
4. Follow the steps on the [Get Started](https://gravity.group.one/get-started) page.

All set!

## Usage

The design system is build with many different CSS classes. This allows you to quickly build apps using the Group.ONE look and feel. For a complete overview and usage of each component, check out the live documentation: https://gravity.group.one/.

## Starting the docs

Documentation of the gravity design system lives in this repository as a NodeJS app. To start it, run:

```bash
yarn doc:serve
```

This will start the local development server. Visit the URL that is listed in the CLI to view the docs.

## Building

To build the gravity library, use the following command:

```bash
yarn lib:build
```

You can also build the docs, this can be done using:

```bash
yarn doc:build
```

## Releasing

Before creating a new release, make sure you have done the following:

1. All your change are in the `main` branch.
2. You have updated the docs (if necessary) to reflect your change.
3. You have tested if your changes worked in the staging environment.

Then it's time to create release.

### Using the gitlab UI

1. In the Gitlab UI, go to "Repository" > "Tags"
2. Click on the "New Tag" button
3. Fill in a tag number, using [semantic versioning](https://semver.org/). Make sure to use `main` as branch and fill in a short description of the changes.
4. Hit "Create tag".

### Using the git CLI.

1. Open a terminal and go to your project.
2. Make sure you are on the `main` branch.
3. Execute `git fetch --tags` to make sure you are up-to-date
4. Execute `git tag "<TAG>" -m "<MSG>"` with `<TAG>` being the tag number, using [semantic versioning](https://semver.org/). and the `<MSG>` a short description of the changes.
5. Execute `git push origin "<TAG>"` with `<TAG>` being the tag you just created.

This will start a pipeline in the CI to publish a new release.
